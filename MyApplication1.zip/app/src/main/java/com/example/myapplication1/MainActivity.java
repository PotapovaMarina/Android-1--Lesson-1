package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity<TextView> extends AppCompatActivity {
    private Button button;
    private EditText editText1;
    private EditText editText2;
    private TextView resultText1;
    private TextView resultText2;
    private TextView textMsg;

    private Float arg1;
    private Float arg2;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button)findViewById(R.id.button);
        editText1=findViewById(R.id.editText1);
        editText2=findViewById(R.id.editText2);
        resultText1= (TextView) findViewById(R.id.resultText1);
        resultText2= (TextView) findViewById(R.id.resultText2);
        textMsg= (TextView) findViewById(R.id.textMsg);


        button.setOnClickListener(view->{
            try{
                arg1 = Float.valueOf(editText1.getText().toString());
                arg2 = Float.valueOf(editText1.getText().toString());
                resultText1.setText(arg1*1000000);
            } catch (NumberFormatException e) {
              //  textMsg.setText("Введите число!");
            }


    });
    }
}